resource  do
  description "Manage things you hate"
end
