command do
  description 'Produces a whale'
  action(:html=>true) do
'
      <p style="font-family:Andale Mono,Menlo">

<br/>       \"""/ 
<br/>        | |
<br/>▄██████████████▄▐█▄▄▄▄█▌
<br/>████████████████▌▀▀██▀▀
<br/>████▄████████████▄▄█▌
<br/>▄▄▄▄▄██████████████▀
<br/>
      </p>
'
  end
end
