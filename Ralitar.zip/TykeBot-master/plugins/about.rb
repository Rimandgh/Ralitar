command do
  description 'About me, the bot!'
  action do
"I'm a chat bot, duh!

You can find my base source available by doing one of the following git clones:

read/write access (request access through github)
git clone git@github.com:tykeal/TykeBot.git

read only access
git clone git://github.com/tykeal/TykeBot.git"
  end
end
