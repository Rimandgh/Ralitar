resource do
  description 'Manage lunch places and get suggestions.'
end
