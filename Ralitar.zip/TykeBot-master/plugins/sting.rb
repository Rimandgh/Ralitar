command do
  description 'Textually perform a percussive sting.'
  action{ "ba dum tsh" }
end
