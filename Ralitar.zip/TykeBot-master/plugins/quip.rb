resource  do
  aliases :quote
  description "Manage quips / quotes."
end
