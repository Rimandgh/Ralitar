resource  do
  description "Manage things you love..."
end
